
"use strict";

let GetActorWaypoint = require('./GetActorWaypoint.js')
let GetWaypoint = require('./GetWaypoint.js')

module.exports = {
  GetActorWaypoint: GetActorWaypoint,
  GetWaypoint: GetWaypoint,
};
