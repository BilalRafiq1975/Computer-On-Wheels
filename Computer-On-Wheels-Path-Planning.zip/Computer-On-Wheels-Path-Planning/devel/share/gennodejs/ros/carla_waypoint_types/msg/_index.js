
"use strict";

let CarlaWaypoint = require('./CarlaWaypoint.js');

module.exports = {
  CarlaWaypoint: CarlaWaypoint,
};
