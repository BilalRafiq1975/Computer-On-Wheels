// Auto-generated. Do not edit!

// (in-package carla_ros_scenario_runner_types.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class CarlaScenarioRunnerStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.status = null;
    }
    else {
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CarlaScenarioRunnerStatus
    // Serialize message field [status]
    bufferOffset = _serializer.uint8(obj.status, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CarlaScenarioRunnerStatus
    let len;
    let data = new CarlaScenarioRunnerStatus(null);
    // Deserialize message field [status]
    data.status = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a message object
    return 'carla_ros_scenario_runner_types/CarlaScenarioRunnerStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '740a173d5d748af3689ca68d3d3cd525';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    #
    # Copyright (c) 2020 Intel Corporation.
    #
    # This work is licensed under the terms of the MIT license.
    # For a copy, see <https://opensource.org/licenses/MIT>.
    #
    uint8 STOPPED = 0
    uint8 STARTING = 1
    uint8 RUNNING = 2
    uint8 SHUTTINGDOWN = 3
    uint8 ERROR = 4
    
    uint8 status
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CarlaScenarioRunnerStatus(null);
    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = 0
    }

    return resolved;
    }
};

// Constants for message
CarlaScenarioRunnerStatus.Constants = {
  STOPPED: 0,
  STARTING: 1,
  RUNNING: 2,
  SHUTTINGDOWN: 3,
  ERROR: 4,
}

module.exports = CarlaScenarioRunnerStatus;
